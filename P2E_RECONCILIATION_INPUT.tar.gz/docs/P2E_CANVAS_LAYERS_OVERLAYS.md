# P2-E — Canvas Layers & Overlays

Status: **implementation candidate pending Windows/manual validation**.

P2-E turns the persistent shared CREATE canvas from a neutral input surface into a real layered production surface, without yet rehousing the validated legacy tools.

## Architecture

The rendering boundary is deliberately split:

```text
CreateWorkspaceState
  └─ CanvasVisualState
       ├─ document geometry
       ├─ CanvasLayerStack metadata
       └─ CanvasOverlayState metadata

SharedCreateCanvas
  └─ QImage render buffers keyed by layer_id
```

`CanvasVisualState` contains no decoded image arrays, project JSON, ProjectStore payload or pipeline state. `ProjectState` remains identity/context state only. Pixel buffers belong to the shared canvas renderer and can later be replaced/updated by P2-G tool adapters or the Paint Engine without turning ProjectState into a second document cache.

## Raster layer order

The semantic roles are:

- `ONION_PREVIOUS`
- `ONION_NEXT`
- `CURRENT_FRAME`

The stack always renders onion layers before the current frame. Layers have explicit visibility and bounded opacity (`0.0..1.0`). The canvas copies incoming `QImage` buffers so it owns the lifetime of its render payload.

## Overlay order

The complete P2-E visual order is:

```text
canvas background
transparency checkerboard
onion previous / onion next
current frame
grid
guides
selection
pivot
```

Grid, guides, rectangular/polygon selection and pivot are visual overlays only. Their APIs update transient canvas visual metadata and never modify frame pixels.

## Geometry and transform

The shared canvas has explicit logical document width/height. If no geometry has been set, the first raster image establishes it.

Rendering and future tools share the same transform:

```text
logical canvas coordinate
  -> zoom
  -> centered document origin
  -> pan offset
  -> widget/view coordinate
```

`canvas_to_view()` and `view_to_canvas()` expose the forward and inverse mapping.

P2-E does not define mouse-wheel zoom policy; that remains intentionally open in the canonical Phase 2 contract.

## Compatibility boundary

P2-E does not move Import, Extract, Select, Clean-up, Align, Character Set or Export off their validated legacy surfaces. The shared canvas remains the alternate persistent center page until the P2-G audit/rehousing work.

No Paint Engine, Mesh, Rig or Animation logic is introduced here.

## Manual validation

On Windows/PySide6:

1. run the complete automated suite;
2. launch Sprite Studio and verify no regressions in Generate/Create/Manage or existing CREATE routes;
3. use the development/test path that exposes the shared canvas, if available;
4. load/set a current frame and verify the transparency background stays behind it;
5. add previous/next onion frames and verify they remain behind the current frame with opacity applied;
6. toggle grid, guides, selection and pivot overlays and verify they track pan/zoom;
7. pan the canvas and verify all raster layers and overlays move as one scene;
8. clear/hide overlays and verify the underlying image is unchanged;
9. switch CREATE route/project context and verify no pointer capture is left active.

P2-E is valid when the complete Windows suite passes and the layered scene introduces no regression to the P2-D baseline.

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QImage, QMouseEvent, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QWidget

from app.canvas_input import (
    CanvasInputController,
    CanvasInputMode,
    CanvasPointerEvent,
    PointerButton,
    PointerPhase,
)
from app.canvas_layers import CanvasRasterRole, CanvasVisualState
from app.create_workspace_state import CreateWorkspaceState


_CURRENT_FRAME_LAYER_ID = 'current-frame'
_ONION_PREVIOUS_LAYER_ID = 'onion-previous'
_ONION_NEXT_LAYER_ID = 'onion-next'


class SharedCreateCanvas(QWidget):
    """Persistent CREATE canvas with centralized input and layered rendering.

    P2-E adds a non-destructive visual scene over the P2-C input foundation.
    ProjectStore/ProjectState still own identities and persistence; this widget
    owns only render buffers corresponding to CanvasVisualState metadata.
    Existing R5c8 CREATE routes remain on their legacy surfaces until P2-G.
    """

    view_transform_changed = Signal(float, float, float)
    context_menu_requested = Signal(float, float)
    raster_layers_changed = Signal()
    overlays_changed = Signal()

    def __init__(
        self,
        *,
        state: CreateWorkspaceState,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._state = state
        self._mouse_capture_requested = False
        self._pan_cursor_active = False
        self._input_controller = CanvasInputController(state.tool, self)
        self._layer_images: dict[str, QImage] = {}

        self.setObjectName('createSharedCanvas')
        self.setProperty('createRole', 'sharedCanvas')
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        self.setMinimumSize(1, 1)

    @property
    def state(self) -> CreateWorkspaceState:
        return self._state

    @property
    def visual_state(self) -> CanvasVisualState:
        return self._state.visual

    @property
    def input_controller(self) -> CanvasInputController:
        return self._input_controller

    @property
    def view_transform(self) -> tuple[float, float, float]:
        view = self._state.view
        return (view.pan_x, view.pan_y, view.zoom)

    @property
    def document_size(self) -> tuple[int, int] | None:
        return self.visual_state.document_size

    @property
    def visible_layer_ids(self) -> tuple[str, ...]:
        return self.visual_state.layers.ids(visible_only=True)

    @property
    def mouse_capture_requested(self) -> bool:
        return self._mouse_capture_requested

    def set_view_transform(self, *, pan_x: float, pan_y: float, zoom: float) -> None:
        self._state.view.set_view_transform(pan_x=pan_x, pan_y=pan_y, zoom=zoom)
        self.view_transform_changed.emit(
            self._state.view.pan_x,
            self._state.view.pan_y,
            self._state.view.zoom,
        )
        self.update()

    def set_document_size(self, width: int, height: int) -> None:
        self.visual_state.set_document_size(width, height)
        self.update()

    def set_raster_layer(
        self,
        layer_id: str,
        role: CanvasRasterRole | str,
        image: QImage | None,
        *,
        visible: bool = True,
        opacity: float = 1.0,
    ) -> None:
        normalized_id = str(layer_id).strip()
        if not normalized_id:
            raise ValueError('Canvas layer id cannot be empty.')
        if image is None:
            self.remove_raster_layer(normalized_id)
            return
        if not isinstance(image, QImage):
            raise TypeError('Shared canvas raster layers require QImage payloads.')
        if image.isNull():
            raise ValueError('Shared canvas raster layer cannot use a null QImage.')
        self.visual_state.layers.upsert(
            normalized_id,
            role,
            visible=visible,
            opacity=opacity,
        )
        self._layer_images[normalized_id] = image.copy()
        if not self.visual_state.has_document_geometry:
            self.visual_state.set_document_size(image.width(), image.height())
        self.raster_layers_changed.emit()
        self.update()

    def remove_raster_layer(self, layer_id: str) -> None:
        normalized_id = str(layer_id).strip()
        if not normalized_id:
            raise ValueError('Canvas layer id cannot be empty.')
        existed = normalized_id in self.visual_state.layers or normalized_id in self._layer_images
        self.visual_state.layers.remove(normalized_id)
        self._layer_images.pop(normalized_id, None)
        if existed:
            self.raster_layers_changed.emit()
            self.update()

    def clear_raster_layers(self) -> None:
        if len(self.visual_state.layers) == 0 and not self._layer_images:
            return
        self.visual_state.layers.clear()
        self._layer_images.clear()
        self.raster_layers_changed.emit()
        self.update()

    def set_layer_visibility(self, layer_id: str, visible: bool) -> None:
        self.visual_state.layers.set_visible(layer_id, visible)
        self.raster_layers_changed.emit()
        self.update()

    def set_layer_opacity(self, layer_id: str, opacity: float) -> None:
        self.visual_state.layers.set_opacity(layer_id, opacity)
        self.raster_layers_changed.emit()
        self.update()

    def set_current_frame(self, image: QImage | None) -> None:
        self.set_raster_layer(
            _CURRENT_FRAME_LAYER_ID,
            CanvasRasterRole.CURRENT_FRAME,
            image,
            opacity=1.0,
        )

    def set_onion_frame(
        self,
        slot: str,
        image: QImage | None,
        *,
        opacity: float = 0.30,
    ) -> None:
        normalized = str(slot).strip().lower()
        if normalized == 'previous':
            layer_id = _ONION_PREVIOUS_LAYER_ID
            role = CanvasRasterRole.ONION_PREVIOUS
        elif normalized == 'next':
            layer_id = _ONION_NEXT_LAYER_ID
            role = CanvasRasterRole.ONION_NEXT
        else:
            raise KeyError(f'Unknown onion-frame slot: {slot}')
        self.set_raster_layer(layer_id, role, image, opacity=opacity)

    def set_grid_overlay(self, visible: bool, *, spacing: float | None = None) -> None:
        self.visual_state.overlays.set_grid(visible, spacing=spacing)
        self.overlays_changed.emit()
        self.update()

    def set_guides(
        self,
        *,
        vertical: tuple[float, ...] = (),
        horizontal: tuple[float, ...] = (),
    ) -> None:
        self.visual_state.overlays.set_guides(vertical=vertical, horizontal=horizontal)
        self.overlays_changed.emit()
        self.update()

    def set_pivot_overlay(self, point: tuple[float, float] | None) -> None:
        self.visual_state.overlays.set_pivot(point)
        self.overlays_changed.emit()
        self.update()

    def set_selection_rect(self, x0: float, y0: float, x1: float, y1: float) -> None:
        self.visual_state.overlays.set_selection_rect(x0, y0, x1, y1)
        self.overlays_changed.emit()
        self.update()

    def set_selection_polygon(self, points: tuple[tuple[float, float], ...]) -> None:
        self.visual_state.overlays.set_selection_polygon(points)
        self.overlays_changed.emit()
        self.update()

    def clear_selection_overlay(self) -> None:
        self.visual_state.overlays.clear_selection()
        self.overlays_changed.emit()
        self.update()

    def clear_scene(self) -> None:
        self.cancel_interaction('canvas-scene-cleared')
        self._layer_images.clear()
        self.visual_state.clear_scene_metadata()
        self.raster_layers_changed.emit()
        self.overlays_changed.emit()
        self.update()

    def content_rect(self) -> QRectF:
        size = self.visual_state.document_size
        if size is None:
            return QRectF()
        width, height = size
        zoom = self._state.view.zoom
        scaled_width = float(width) * zoom
        scaled_height = float(height) * zoom
        left = ((float(self.width()) - scaled_width) / 2.0) + self._state.view.pan_x
        top = ((float(self.height()) - scaled_height) / 2.0) + self._state.view.pan_y
        return QRectF(left, top, scaled_width, scaled_height)

    def canvas_to_view(self, x: float, y: float) -> QPointF:
        rect = self.content_rect()
        zoom = self._state.view.zoom
        return QPointF(rect.left() + float(x) * zoom, rect.top() + float(y) * zoom)

    def view_to_canvas(self, x: float, y: float) -> QPointF:
        rect = self.content_rect()
        zoom = self._state.view.zoom
        if zoom <= 0:
            raise RuntimeError('Canvas zoom must remain positive.')
        return QPointF((float(x) - rect.left()) / zoom, (float(y) - rect.top()) / zoom)

    def cancel_interaction(self, reason: str = 'canvas-context-changed') -> None:
        self._input_controller.invalidate_context(reason)

    # CanvasNeutralSink -------------------------------------------------

    def begin_pan(self) -> None:
        self._pan_cursor_active = True
        self.setCursor(Qt.CursorShape.ClosedHandCursor)

    def pan_by(self, dx: float, dy: float) -> None:
        view = self._state.view
        view.set_view_transform(
            pan_x=view.pan_x + float(dx),
            pan_y=view.pan_y + float(dy),
            zoom=view.zoom,
        )
        self.view_transform_changed.emit(view.pan_x, view.pan_y, view.zoom)
        self.update()

    def end_pan(self) -> None:
        self._pan_cursor_active = False
        if self._input_controller.mode is CanvasInputMode.CANVAS_NEUTRAL:
            self.setCursor(Qt.CursorShape.OpenHandCursor)
        else:
            self.unsetCursor()

    def request_context_menu(self, x: float, y: float) -> None:
        self.context_menu_requested.emit(float(x), float(y))

    def set_mouse_capture(self, active: bool) -> None:
        requested = bool(active)
        self._mouse_capture_requested = requested
        if requested:
            if self.isVisible() and QWidget.mouseGrabber() is not self:
                self.grabMouse()
            return
        if QWidget.mouseGrabber() is self:
            self.releaseMouse()

    # QWidget pointer adapter ------------------------------------------

    def mousePressEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        self.setFocus(Qt.FocusReason.MouseFocusReason)
        self._dispatch_mouse_event(event, PointerPhase.PRESS)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        self._dispatch_mouse_event(event, PointerPhase.MOVE)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        self._dispatch_mouse_event(event, PointerPhase.RELEASE)

    def hideEvent(self, event) -> None:  # type: ignore[override]
        self.cancel_interaction('canvas-hidden')
        super().hideEvent(event)

    def closeEvent(self, event) -> None:  # type: ignore[override]
        self.cancel_interaction('canvas-closed')
        super().closeEvent(event)

    def paintEvent(self, event) -> None:  # type: ignore[override]
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, False)
        painter.fillRect(self.rect(), QColor(36, 38, 43))

        document_rect = self.content_rect()
        if document_rect.isEmpty():
            return

        overlays = self.visual_state.overlays
        if overlays.show_transparency:
            self._paint_transparency(painter, document_rect)
        else:
            painter.fillRect(document_rect, QColor(20, 21, 24))

        for layer in self.visual_state.layers.ordered(visible_only=True):
            image = self._layer_images.get(layer.layer_id)
            if image is None or image.isNull():
                continue
            painter.save()
            painter.setOpacity(layer.opacity)
            painter.drawImage(document_rect, image)
            painter.restore()

        self._paint_grid(painter, document_rect)
        self._paint_guides(painter, document_rect)
        self._paint_selection(painter)
        self._paint_pivot(painter)

    def _paint_transparency(self, painter: QPainter, rect: QRectF) -> None:
        checker = max(4, int(round(8.0 * min(self._state.view.zoom, 2.0))))
        painter.save()
        painter.setClipRect(rect)
        left = int(math.floor(rect.left() / checker) * checker)
        top = int(math.floor(rect.top() / checker) * checker)
        right = int(math.ceil(rect.right()))
        bottom = int(math.ceil(rect.bottom()))
        light = QColor(70, 73, 79)
        dark = QColor(52, 55, 61)
        row = 0
        for y in range(top, bottom, checker):
            column = 0
            for x in range(left, right, checker):
                painter.fillRect(
                    x,
                    y,
                    checker,
                    checker,
                    light if ((row + column) % 2 == 0) else dark,
                )
                column += 1
            row += 1
        painter.restore()

    def _paint_grid(self, painter: QPainter, rect: QRectF) -> None:
        overlays = self.visual_state.overlays
        if not overlays.show_grid:
            return
        step = overlays.grid_spacing * self._state.view.zoom
        if step < 4.0:
            return
        painter.save()
        painter.setClipRect(rect)
        painter.setPen(QPen(QColor(255, 255, 255, 32), 1))
        x = rect.left()
        while x <= rect.right() + 0.5:
            painter.drawLine(QPointF(x, rect.top()), QPointF(x, rect.bottom()))
            x += step
        y = rect.top()
        while y <= rect.bottom() + 0.5:
            painter.drawLine(QPointF(rect.left(), y), QPointF(rect.right(), y))
            y += step
        painter.restore()

    def _paint_guides(self, painter: QPainter, rect: QRectF) -> None:
        overlays = self.visual_state.overlays
        if not overlays.vertical_guides and not overlays.horizontal_guides:
            return
        painter.save()
        painter.setClipRect(rect)
        painter.setPen(QPen(QColor(80, 190, 255, 190), 1))
        for logical_x in overlays.vertical_guides:
            x = self.canvas_to_view(logical_x, 0.0).x()
            painter.drawLine(QPointF(x, rect.top()), QPointF(x, rect.bottom()))
        for logical_y in overlays.horizontal_guides:
            y = self.canvas_to_view(0.0, logical_y).y()
            painter.drawLine(QPointF(rect.left(), y), QPointF(rect.right(), y))
        painter.restore()

    def _paint_selection(self, painter: QPainter) -> None:
        overlays = self.visual_state.overlays
        if overlays.selection_kind is None:
            return
        pen = QPen(QColor(245, 245, 245, 220), 1, Qt.PenStyle.DashLine)
        painter.save()
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        if overlays.selection_kind == 'rect' and overlays.selection_rect is not None:
            x, y, width, height = overlays.selection_rect
            top_left = self.canvas_to_view(x, y)
            bottom_right = self.canvas_to_view(x + width, y + height)
            painter.drawRect(QRectF(top_left, bottom_right).normalized())
        elif overlays.selection_kind == 'polygon' and overlays.selection_points:
            path = QPainterPath()
            first = self.canvas_to_view(*overlays.selection_points[0])
            path.moveTo(first)
            for point in overlays.selection_points[1:]:
                path.lineTo(self.canvas_to_view(*point))
            if len(overlays.selection_points) > 2:
                path.closeSubpath()
            painter.drawPath(path)
        painter.restore()

    def _paint_pivot(self, painter: QPainter) -> None:
        pivot = self.visual_state.overlays.pivot
        if pivot is None:
            return
        point = self.canvas_to_view(*pivot)
        arm = max(4.0, 6.0 * self._state.view.zoom)
        painter.save()
        painter.setPen(QPen(QColor(255, 80, 80, 230), max(1, int(self._state.view.zoom // 3))))
        painter.drawLine(QPointF(point.x() - arm, point.y()), QPointF(point.x() + arm, point.y()))
        painter.drawLine(QPointF(point.x(), point.y() - arm), QPointF(point.x(), point.y() + arm))
        painter.restore()

    def _dispatch_mouse_event(self, event: QMouseEvent, phase: PointerPhase) -> None:
        pointer_event = CanvasPointerEvent(
            phase=phase,
            x=float(event.position().x()),
            y=float(event.position().y()),
            button=self._button(event.button()),
            buttons=self._buttons(event.buttons()),
            modifiers=self._modifiers(event.modifiers()),
        )
        handled = self._input_controller.handle_pointer_event(pointer_event)
        if handled or self._input_controller.mode is CanvasInputMode.TOOL_ACTIVE:
            event.accept()
        else:
            event.ignore()

    @staticmethod
    def _button(button: Qt.MouseButton) -> PointerButton:
        if button == Qt.MouseButton.LeftButton:
            return PointerButton.LEFT
        if button == Qt.MouseButton.RightButton:
            return PointerButton.RIGHT
        if button == Qt.MouseButton.MiddleButton:
            return PointerButton.MIDDLE
        if button == Qt.MouseButton.NoButton:
            return PointerButton.NONE
        return PointerButton.OTHER

    @classmethod
    def _buttons(cls, buttons: Qt.MouseButton) -> frozenset[PointerButton]:
        active: set[PointerButton] = set()
        for qt_button, pointer_button in (
            (Qt.MouseButton.LeftButton, PointerButton.LEFT),
            (Qt.MouseButton.RightButton, PointerButton.RIGHT),
            (Qt.MouseButton.MiddleButton, PointerButton.MIDDLE),
        ):
            if buttons & qt_button:
                active.add(pointer_button)
        return frozenset(active)

    @staticmethod
    def _modifiers(modifiers: Qt.KeyboardModifier) -> frozenset[str]:
        active: set[str] = set()
        for flag, name in (
            (Qt.KeyboardModifier.ShiftModifier, 'shift'),
            (Qt.KeyboardModifier.ControlModifier, 'control'),
            (Qt.KeyboardModifier.AltModifier, 'alt'),
            (Qt.KeyboardModifier.MetaModifier, 'meta'),
        ):
            if modifiers & flag:
                active.add(name)
        return frozenset(active)

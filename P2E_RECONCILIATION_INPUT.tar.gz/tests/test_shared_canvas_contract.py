from __future__ import annotations

from pathlib import Path
import unittest


class SharedCanvasSourceContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        root = Path(__file__).resolve().parents[1]
        cls.input_source = (root / 'app' / 'canvas_input.py').read_text(encoding='utf-8')
        cls.canvas_source = (root / 'app' / 'shared_canvas.py').read_text(encoding='utf-8')
        cls.shell_source = (root / 'app' / 'create_workspace_shell.py').read_text(encoding='utf-8')

    def test_controller_freezes_neutral_and_tool_active_states(self) -> None:
        self.assertIn("CANVAS_NEUTRAL = 'canvas_neutral'", self.input_source)
        self.assertIn("TOOL_ACTIVE = 'tool_active'", self.input_source)
        self.assertIn('class CanvasInputController', self.input_source)

    def test_active_tool_has_no_neutral_fallback_path(self) -> None:
        self.assertIn('return self._handle_tool_event(event)', self.input_source)
        self.assertIn('Never degrade an inconsistent active-tool state into neutral mode.', self.input_source)

    def test_interaction_cancel_releases_mouse_capture(self) -> None:
        self.assertIn("handler.cancel_interaction(str(reason))", self.input_source)
        self.assertIn('self._neutral_sink.set_mouse_capture(False)', self.input_source)
        self.assertIn("self.cancel_interaction('canvas-hidden')", self.canvas_source)

    def test_shared_canvas_is_persistent_but_legacy_surface_remains_default(self) -> None:
        self.assertIn("setObjectName('createCenterSurfaceStack')", self.shell_source)
        self.assertIn('self._shared_canvas = SharedCreateCanvas', self.shell_source)
        self.assertIn('self._center_stack.addWidget(self._production_surface)', self.shell_source)
        self.assertIn('self._center_stack.addWidget(self._shared_canvas)', self.shell_source)
        self.assertIn('self._center_stack.setCurrentWidget(self._production_surface)', self.shell_source)

    def test_p2c_does_not_build_general_context_menu_early(self) -> None:
        self.assertNotIn('QMenu', self.canvas_source)
        self.assertNotIn('QAction', self.canvas_source)
        self.assertIn('context_menu_requested = Signal(float, float)', self.canvas_source)

    def test_p2e_adds_layers_without_freezing_wheel_or_mesh_policy(self) -> None:
        self.assertNotIn('wheelEvent', self.canvas_source)
        self.assertIn('CanvasVisualState', self.canvas_source)
        self.assertIn('set_onion_frame', self.canvas_source)
        self.assertNotIn('mesh', self.canvas_source.lower())


if __name__ == '__main__':
    unittest.main()

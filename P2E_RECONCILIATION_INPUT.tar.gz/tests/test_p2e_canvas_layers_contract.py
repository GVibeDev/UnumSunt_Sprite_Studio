from __future__ import annotations

from pathlib import Path
import unittest


class P2ECanvasLayersContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        root = Path(__file__).resolve().parents[1]
        cls.layers = (root / 'app' / 'canvas_layers.py').read_text(encoding='utf-8')
        cls.canvas = (root / 'app' / 'shared_create_canvas.py').read_text(encoding='utf-8')
        cls.main = (root / 'app' / 'main_window.py').read_text(encoding='utf-8')
        cls.state = (root / 'app' / 'create_workspace_state.py').read_text(encoding='utf-8')
        cls.doc = (root / 'docs' / 'P2E_CANVAS_LAYERS_OVERLAYS.md').read_text(encoding='utf-8')

    def test_shared_canvas_is_now_real_rgba_renderer(self) -> None:
        self.assertIn('CanvasLayerStack()', self.canvas)
        self.assertIn('painter.drawImage(target, self._current_qimage)', self.canvas)
        self.assertIn('show_checkerboard', self.canvas)

    def test_main_window_feeds_existing_nondestructive_rgba_result(self) -> None:
        self.assertIn('self.workstation_shell.set_create_canvas_frame_layers(rgba, onion_rgba)', self.main)
        self.assertIn('self.workstation_shell.clear_create_canvas_frame_layers()', self.main)

    def test_overlay_foundations_cover_required_p2e_geometry(self) -> None:
        self.assertIn('CanvasSelectionRect', self.layers)
        self.assertIn('CanvasGuideState', self.layers)
        self.assertIn('pivot:', self.layers)
        self.assertIn('ground_y:', self.layers)
        self.assertIn('onion_skin_enabled', self.state)
        self.assertIn('show_pixel_grid', self.state)

    def test_layer_cache_is_explicitly_not_project_persistence(self) -> None:
        self.assertNotIn('from app.project_store', self.layers)
        self.assertNotIn('from app.project_session', self.layers)
        self.assertNotIn('save(', self.layers)
        self.assertIn('presentation-only', self.doc)
        self.assertIn('not an edit buffer', self.doc)

    def test_p2e_does_not_turn_on_unfrozen_onion_behavior_automatically(self) -> None:
        self.assertIn('onion_skin_enabled: bool = False', self.state)
        self.assertIn('P2-F', self.doc)
        self.assertIn('does not automatically choose the previous or next frame', self.doc)

    def test_coordinate_conversion_is_canvas_owned_for_future_tools(self) -> None:
        self.assertIn('def image_to_canvas(', self.canvas)
        self.assertIn('def canvas_to_image(', self.canvas)
        self.assertIn('image coordinates', self.doc)


if __name__ == '__main__':
    unittest.main()

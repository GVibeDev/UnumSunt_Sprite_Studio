from __future__ import annotations

import importlib.util
import os
import unittest


PYSIDE6_AVAILABLE = importlib.util.find_spec('PySide6') is not None

if PYSIDE6_AVAILABLE:
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    from PySide6.QtGui import QImage
    from PySide6.QtWidgets import QApplication

    from app.canvas_layers import CanvasRasterRole
    from app.create_workspace_state import CreateWorkspaceState
    from app.shared_canvas import SharedCreateCanvas


@unittest.skipUnless(PYSIDE6_AVAILABLE, 'PySide6 is not installed in this test interpreter.')
class SharedCanvasLayerRenderingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = QApplication.instance() or QApplication([])

    def test_first_raster_establishes_document_geometry(self) -> None:
        canvas = SharedCreateCanvas(state=CreateWorkspaceState())
        image = QImage(32, 24, QImage.Format.Format_RGBA8888)
        image.fill(0)
        canvas.set_current_frame(image)
        self.assertEqual(canvas.document_size, (32, 24))
        self.assertEqual(canvas.visible_layer_ids, ('current-frame',))

    def test_onion_layers_render_before_current_frame(self) -> None:
        canvas = SharedCreateCanvas(state=CreateWorkspaceState())
        image = QImage(16, 16, QImage.Format.Format_RGBA8888)
        image.fill(0)
        canvas.set_current_frame(image)
        canvas.set_onion_frame('next', image, opacity=0.2)
        canvas.set_onion_frame('previous', image, opacity=0.3)
        self.assertEqual(
            canvas.visible_layer_ids,
            ('onion-previous', 'onion-next', 'current-frame'),
        )

    def test_generic_raster_layer_can_be_hidden_without_removing_payload(self) -> None:
        canvas = SharedCreateCanvas(state=CreateWorkspaceState())
        image = QImage(8, 8, QImage.Format.Format_RGBA8888)
        image.fill(0)
        canvas.set_raster_layer('preview', CanvasRasterRole.ONION_PREVIOUS, image)
        self.assertEqual(canvas.visible_layer_ids, ('preview',))
        canvas.set_layer_visibility('preview', False)
        self.assertEqual(canvas.visible_layer_ids, ())
        canvas.set_layer_visibility('preview', True)
        self.assertEqual(canvas.visible_layer_ids, ('preview',))

    def test_canvas_coordinate_transform_preserves_pan_and_zoom(self) -> None:
        state = CreateWorkspaceState()
        canvas = SharedCreateCanvas(state=state)
        canvas.resize(200, 100)
        canvas.set_document_size(20, 10)
        canvas.set_view_transform(pan_x=10, pan_y=-5, zoom=2)
        origin = canvas.canvas_to_view(0, 0)
        self.assertAlmostEqual(origin.x(), 90.0)
        self.assertAlmostEqual(origin.y(), 35.0)
        logical = canvas.view_to_canvas(origin.x() + 8, origin.y() + 6)
        self.assertAlmostEqual(logical.x(), 4.0)
        self.assertAlmostEqual(logical.y(), 3.0)

    def test_overlay_api_mutates_visual_state_only(self) -> None:
        state = CreateWorkspaceState()
        canvas = SharedCreateCanvas(state=state)
        canvas.set_grid_overlay(True, spacing=4)
        canvas.set_guides(vertical=(3,), horizontal=(6,))
        canvas.set_pivot_overlay((5, 7))
        canvas.set_selection_rect(1, 2, 8, 9)
        overlays = state.visual.overlays
        self.assertTrue(overlays.show_grid)
        self.assertEqual(overlays.vertical_guides, (3.0,))
        self.assertEqual(overlays.horizontal_guides, (6.0,))
        self.assertEqual(overlays.pivot, (5.0, 7.0))
        self.assertEqual(overlays.selection_kind, 'rect')


if __name__ == '__main__':
    unittest.main()
